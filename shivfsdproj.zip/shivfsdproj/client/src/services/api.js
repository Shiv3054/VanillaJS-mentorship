import axios from 'axios'

const baseURL = ''

export function api(token) {
  const instance = axios.create({ baseURL })
  instance.interceptors.request.use((config) => {
    if (token) config.headers.Authorization = `Bearer ${token}`
    return config
  })
  return instance
}
