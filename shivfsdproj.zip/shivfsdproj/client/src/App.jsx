import { Navigate, Route, Routes } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import Login from './pages/Login.jsx'
import Signup from './pages/Signup.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Mentors from './pages/Mentors.jsx'
import Mentees from './pages/Mentees.jsx'
import Sessions from './pages/Sessions.jsx'
import Goals from './pages/Goals.jsx'
import Assignments from './pages/Assignments.jsx'
import { useAuthContext } from './context/AuthContext.jsx'

function PrivateRoute({ children }) {
  const { token } = useAuthContext()
  if (!token) return <Navigate to="/login" replace />
  return children
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route
        path="/"
        element={
          <PrivateRoute>
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="mentors" element={<Mentors />} />
        <Route path="mentees" element={<Mentees />} />
        <Route path="assignments" element={<Assignments />} />
        <Route path="sessions" element={<Sessions />} />
        <Route path="goals" element={<Goals />} />
      </Route>
    </Routes>
  )
}
