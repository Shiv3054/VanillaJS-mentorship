import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuthContext } from '../context/AuthContext.jsx'

export default function Layout() {
  const { user, logout } = useAuthContext()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">Mentorship Tracker</div>
        <nav>
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/mentors">Mentors</NavLink>
          <NavLink to="/mentees">Mentees</NavLink>
          <NavLink to="/assignments">Assignments</NavLink>
          <NavLink to="/sessions">Sessions</NavLink>
          <NavLink to="/goals">Goals</NavLink>
        </nav>
      </aside>
      <main className="content">
        <header className="topbar">
          <div />
          <div className="user">
            <span>{user?.name} ({user?.role})</span>
            <button className="btn" onClick={handleLogout}>Logout</button>
          </div>
        </header>
        <div className="page">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
