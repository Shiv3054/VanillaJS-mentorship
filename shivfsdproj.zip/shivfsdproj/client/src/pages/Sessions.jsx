import { useEffect, useState } from 'react'
import { useAuthContext } from '../context/AuthContext.jsx'
import { api } from '../services/api'

export default function Sessions() {
  const { token, user } = useAuthContext()
  const client = api(token)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ mentor: '', mentee: '', date: '', notes: '' })
  const [mentors, setMentors] = useState([])
  const [mentees, setMentees] = useState([])
  const [error, setError] = useState('')

  async function load() {
    setLoading(true)
    try {
      const [sessionsRes, mentorsRes, menteesRes] = await Promise.all([
        client.get('/api/sessions'),
        client.get('/api/users/mentors'),
        client.get('/api/users/mentees')
      ])
      setItems(sessionsRes.data)
      setMentors(mentorsRes.data)
      setMentees(menteesRes.data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  async function create(e) {
    e.preventDefault()
    setError('')
    try {
      await client.post('/api/sessions', {
        mentor: form.mentor,
        mentee: form.mentee,
        date: form.date,
        notes: form.notes
      })
      setForm({ mentor: '', mentee: '', date: '', notes: '' })
      await load()
    } catch (e) {
      setError(e?.response?.data?.message || 'Create failed')
    }
  }

  async function remove(id) {
    await client.delete(`/api/sessions/${id}`)
    await load()
  }

  return (
    <div className="grid two">
      <div className="card">
        <h2>Sessions</h2>
        {loading ? 'Loading...' : (
          <div className="table">
            <div className="row head">
              <div>Mentor</div>
              <div>Mentee</div>
              <div>Date</div>
              <div>Status</div>
              <div>Actions</div>
            </div>
            {items.map(s => (
              <div className="row" key={s._id}>
                <div>{s.mentor?.name}</div>
                <div>{s.mentee?.name}</div>
                <div>{new Date(s.date).toLocaleString()}</div>
                <div>{s.status}</div>
                <div>
                  {(user?.role === 'admin' || user?.role === 'mentor') && (
                    <button className="btn" onClick={() => remove(s._id)}>Delete</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {(user?.role === 'admin' || user?.role === 'mentor') && (
        <div className="card">
          <h2>Create Session</h2>
          {error && <div className="alert">{error}</div>}
          <form onSubmit={create} className="form">
            <label>Mentor</label>
            <select value={form.mentor} onChange={e => setForm(f => ({ ...f, mentor: e.target.value }))} required>
              <option value="">Select mentor</option>
              {mentors.map(m => <option key={m._id} value={m._id}>{m.name} ({m.email})</option>)}
            </select>
            <label>Mentee</label>
            <select value={form.mentee} onChange={e => setForm(f => ({ ...f, mentee: e.target.value }))} required>
              <option value="">Select mentee</option>
              {mentees.map(m => <option key={m._id} value={m._id}>{m.name} ({m.email})</option>)}
            </select>
            <label>Date</label>
            <input type="datetime-local" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} required />
            <label>Notes</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            <button className="btn primary" type="submit">Create</button>
          </form>
        </div>
      )}
    </div>
  )
}
