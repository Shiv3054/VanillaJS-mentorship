import { useEffect, useState } from 'react'
import { useAuthContext } from '../context/AuthContext.jsx'
import { api } from '../services/api'

export default function Dashboard() {
  const { token } = useAuthContext()
  const [data, setData] = useState({ mentors: 0, mentees: 0, assignments: 0, sessions: 0, goals: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    const client = api(token)
    async function load() {
      try {
        const [mentors, mentees, assignments, sessions, goals] = await Promise.all([
          client.get('/api/users/mentors'),
          client.get('/api/users/mentees'),
          client.get('/api/assignments'),
          client.get('/api/sessions'),
          client.get('/api/goals')
        ])
        if (!mounted) return
        setData({
          mentors: mentors.data.length,
          mentees: mentees.data.length,
          assignments: assignments.data.length,
          sessions: sessions.data.length,
          goals: goals.data.length
        })
      } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
    return () => { mounted = false }
  }, [token])

  if (loading) return <div>Loading...</div>

  return (
    <div className="grid">
      <div className="card stat"><h3>Mentors</h3><p className="num">{data.mentors}</p></div>
      <div className="card stat"><h3>Mentees</h3><p className="num">{data.mentees}</p></div>
      <div className="card stat"><h3>Assignments</h3><p className="num">{data.assignments}</p></div>
      <div className="card stat"><h3>Sessions</h3><p className="num">{data.sessions}</p></div>
      <div className="card stat"><h3>Goals</h3><p className="num">{data.goals}</p></div>
    </div>
  )
}
