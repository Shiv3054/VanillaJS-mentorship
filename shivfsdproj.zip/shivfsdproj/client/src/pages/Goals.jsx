import { useEffect, useState } from 'react'
import { useAuthContext } from '../context/AuthContext.jsx'
import { api } from '../services/api'

export default function Goals() {
  const { token } = useAuthContext()
  const client = api(token)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ title: '', description: '', progress: 0, status: 'not_started' })
  const [error, setError] = useState('')

  async function load() {
    setLoading(true)
    try {
      const res = await client.get('/api/goals')
      setItems(res.data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  async function create(e) {
    e.preventDefault()
    setError('')
    try {
      await client.post('/api/goals', form)
      setForm({ title: '', description: '', progress: 0, status: 'not_started' })
      await load()
    } catch (e) {
      setError(e?.response?.data?.message || 'Create failed')
    }
  }

  async function update(item, patch) {
    await client.put(`/api/goals/${item._id}`, { ...item, ...patch })
    await load()
  }

  async function remove(id) {
    await client.delete(`/api/goals/${id}`)
    await load()
  }

  return (
    <div className="grid two">
      <div className="card">
        <h2>My Goals</h2>
        {loading ? 'Loading...' : (
          <div className="table">
            <div className="row head">
              <div>Title</div>
              <div>Progress</div>
              <div>Status</div>
              <div>Actions</div>
            </div>
            {items.map(g => (
              <div className="row" key={g._id}>
                <div title={g.description}>{g.title}</div>
                <div>{g.progress}%</div>
                <div>{g.status}</div>
                <div className="actions">
                  <button className="btn" onClick={() => update(g, { progress: Math.min(100, (g.progress || 0) + 10), status: (g.progress + 10) >= 100 ? 'completed' : 'in_progress' })}>+10%</button>
                  <button className="btn" onClick={() => remove(g._id)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card">
        <h2>Create Goal</h2>
        {error && <div className="alert">{error}</div>}
        <form onSubmit={create} className="form">
          <label>Title</label>
          <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
          <label>Description</label>
          <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          <label>Progress</label>
          <input type="number" min="0" max="100" value={form.progress} onChange={e => setForm(f => ({ ...f, progress: Number(e.target.value) }))} />
          <label>Status</label>
          <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            <option value="not_started">Not started</option>
            <option value="in_progress">In progress</option>
            <option value="completed">Completed</option>
          </select>
          <button className="btn primary" type="submit">Create</button>
        </form>
      </div>
    </div>
  )
}
