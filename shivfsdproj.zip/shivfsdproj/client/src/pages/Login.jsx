import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthContext } from '../context/AuthContext.jsx'
import { api } from '../services/api'

export default function Login() {
  const [email, setEmail] = useState('admin@example.com')
  const [password, setPassword] = useState('Passw0rd!')
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const { login } = useAuthContext()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try {
      const res = await api().post('/api/auth/login', { email, password })
      login(res.data.token, res.data.user)
      navigate('/')
    } catch (err) {
      setError(err?.response?.data?.message || 'Login failed')
    }
  }

  return (
    <div className="centered">
      <form className="card" onSubmit={onSubmit}>
        <h2>Login</h2>
        {error && <div className="alert">{error}</div>}
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
        <label>Password</label>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />
        <button className="btn primary" type="submit">Sign In</button>
      </form>
    </div>
  )
}
