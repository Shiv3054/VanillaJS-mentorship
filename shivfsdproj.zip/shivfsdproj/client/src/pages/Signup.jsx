import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../services/api'

export default function Signup() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('mentee')
  const [error, setError] = useState('')
  const [ok, setOk] = useState('')
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setError(''); setOk('')
    try {
      await api().post('/api/auth/register', { name, email, password, role })
      setOk('Account created. You can login now.')
      setTimeout(() => navigate('/login'), 800)
    } catch (err) {
      setError(err?.response?.data?.message || 'Signup failed')
    }
  }

  return (
    <div className="centered">
      <form className="card" onSubmit={onSubmit}>
        <h2>Sign Up</h2>
        {error && <div className="alert">{error}</div>}
        {ok && <div className="alert" style={{background:'#153a24',borderColor:'#1f5133',color:'#bff0d1'}}>{ok}</div>}
        <label>Name</label>
        <input value={name} onChange={(e) => setName(e.target.value)} required />
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
        <label>Password</label>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />
        <label>Role</label>
        <select value={role} onChange={(e)=>setRole(e.target.value)}>
          <option value="mentee">Mentee</option>
          <option value="mentor">Mentor</option>
          <option value="admin">Admin</option>
        </select>
        <button className="btn primary" type="submit">Create Account</button>
        <div style={{marginTop:8,color:'#94a3b8'}}>
          Already have an account? <a href="/login">Login</a>
        </div>
      </form>
    </div>
  )
}
