import { useEffect, useState } from 'react'
import { useAuthContext } from '../context/AuthContext.jsx'
import { api } from '../services/api'

export default function Assignments() {
  const { token, user } = useAuthContext()
  const client = api(token)
  const [mentors, setMentors] = useState([])
  const [mentees, setMentees] = useState([])
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ mentor: '', mentee: '' })
  const [error, setError] = useState('')

  async function loadAll() {
    setLoading(true)
    try {
      const [mentorsRes, menteesRes, assignmentsRes] = await Promise.all([
        client.get('/api/users/mentors'),
        client.get('/api/users/mentees'),
        client.get('/api/assignments')
      ])
      setMentors(mentorsRes.data)
      setMentees(menteesRes.data)
      setItems(assignmentsRes.data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadAll() }, [])

  async function create(e) {
    e.preventDefault()
    setError('')
    try {
      await client.post('/api/assignments', form)
      setForm({ mentor: '', mentee: '' })
      await loadAll()
    } catch (e) {
      setError(e?.response?.data?.message || 'Create failed')
    }
  }

  async function remove(id) {
    await client.delete(`/api/assignments/${id}`)
    await loadAll()
  }

  return (
    <div className="grid two">
      <div className="card">
        <h2>Assignments</h2>
        {loading ? 'Loading...' : (
          <div className="table">
            <div className="row head">
              <div>Mentor</div>
              <div>Mentee</div>
              <div>Actions</div>
            </div>
            {items.map(a => (
              <div className="row" key={a._id}>
                <div>{a.mentor?.name}</div>
                <div>{a.mentee?.name}</div>
                <div>
                  {(user?.role === 'admin' || user?.role === 'mentor') && (
                    <button className="btn" onClick={() => remove(a._id)}>Remove</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {(user?.role === 'admin' || user?.role === 'mentor') && (
        <div className="card">
          <h2>Create Assignment</h2>
          {error && <div className="alert">{error}</div>}
          <form onSubmit={create} className="form">
            <label>Mentor</label>
            <select value={form.mentor} onChange={e => setForm(f => ({ ...f, mentor: e.target.value }))} required>
              <option value="">Select mentor</option>
              {mentors.map(m => <option key={m._id} value={m._id}>{m.name} ({m.email})</option>)}
            </select>
            <label>Mentee</label>
            <select value={form.mentee} onChange={e => setForm(f => ({ ...f, mentee: e.target.value }))} required>
              <option value="">Select mentee</option>
              {mentees.map(m => <option key={m._id} value={m._id}>{m.name} ({m.email})</option>)}
            </select>
            <button className="btn primary" type="submit">Assign</button>
          </form>
        </div>
      )}
    </div>
  )
}
