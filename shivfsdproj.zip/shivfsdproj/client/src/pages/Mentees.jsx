import { useEffect, useState } from 'react'
import { useAuthContext } from '../context/AuthContext.jsx'
import { api } from '../services/api'

export default function Mentees() {
  const { token } = useAuthContext()
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    const client = api(token)
    client.get('/api/users/mentees')
      .then(res => { if (mounted) setItems(res.data) })
      .finally(() => mounted && setLoading(false))
    return () => { mounted = false }
  }, [token])

  if (loading) return <div>Loading...</div>

  return (
    <div className="card">
      <h2>Mentees</h2>
      <div className="table">
        <div className="row head">
          <div>Name</div>
          <div>Email</div>
          <div>Role</div>
        </div>
        {items.map(m => (
          <div className="row" key={m._id}>
            <div>{m.name}</div>
            <div>{m.email}</div>
            <div>{m.role}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
