import mongoose from 'mongoose';

const goalSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  description: { type: String },
  progress: { type: Number, min: 0, max: 100, default: 0 },
  status: { type: String, enum: ['not_started', 'in_progress', 'completed'], default: 'not_started' }
}, { timestamps: true });

export default mongoose.model('Goal', goalSchema);
