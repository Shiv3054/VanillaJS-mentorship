import mongoose from 'mongoose';

const assignmentSchema = new mongoose.Schema({
  mentor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  mentee: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
}, { timestamps: true, indexes: [{ fields: { mentor: 1, mentee: 1 }, options: { unique: true } }] });

assignmentSchema.index({ mentor: 1, mentee: 1 }, { unique: true })

export default mongoose.model('Assignment', assignmentSchema);
