import { Router } from 'express';
import Assignment from '../models/Assignment.js';
import { auth } from '../middleware/auth.js';

const router = Router();

router.get('/', auth(['admin', 'mentor', 'mentee']), async (req, res) => {
  const filter = {};
  if (req.user.role === 'mentor') filter.mentor = req.user.id;
  if (req.user.role === 'mentee') filter.mentee = req.user.id;
  const items = await Assignment.find(filter).populate('mentor mentee', 'name email role');
  res.json(items);
});

router.post('/', auth(['admin', 'mentor']), async (req, res) => {
  try {
    const { mentor, mentee } = req.body;
    const item = await Assignment.create({ mentor, mentee });
    const populated = await item.populate('mentor mentee', 'name email role');
    res.status(201).json(populated);
  } catch (e) {
    if (e.code === 11000) return res.status(400).json({ message: 'Assignment already exists' });
    res.status(400).json({ message: 'Create failed' });
  }
});

router.delete('/:id', auth(['admin', 'mentor']), async (req, res) => {
  try {
    await Assignment.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ message: 'Delete failed' });
  }
});

export default router;
