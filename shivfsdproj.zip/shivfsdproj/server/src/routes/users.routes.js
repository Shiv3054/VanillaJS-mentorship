import { Router } from 'express';
import User from '../models/User.js';
import { auth } from '../middleware/auth.js';

const router = Router();

router.get('/me', auth(), async (req, res) => {
  const me = await User.findById(req.user.id).select('-password');
  res.json(me);
});

router.get('/mentors', auth(['admin', 'mentor', 'mentee']), async (req, res) => {
  const mentors = await User.find({ role: 'mentor' }).select('-password');
  res.json(mentors);
});

router.get('/mentees', auth(['admin', 'mentor']), async (req, res) => {
  const mentees = await User.find({ role: 'mentee' }).select('-password');
  res.json(mentees);
});

export default router;
