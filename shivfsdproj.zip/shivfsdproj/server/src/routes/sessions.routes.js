import { Router } from 'express';
import Session from '../models/Session.js';
import { auth } from '../middleware/auth.js';

const router = Router();

router.get('/', auth(['admin', 'mentor', 'mentee']), async (req, res) => {
  const filter = {};
  if (req.user.role === 'mentor') filter.mentor = req.user.id;
  if (req.user.role === 'mentee') filter.mentee = req.user.id;
  const items = await Session.find(filter).populate('mentor mentee', 'name email role');
  res.json(items);
});

router.post('/', auth(['admin', 'mentor']), async (req, res) => {
  try {
    const { mentor, mentee, date, notes, status } = req.body;
    const item = await Session.create({ mentor, mentee, date, notes, status });
    res.status(201).json(item);
  } catch (e) {
    res.status(400).json({ message: 'Create failed' });
  }
});

router.put('/:id', auth(['admin', 'mentor']), async (req, res) => {
  try {
    const item = await Session.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(item);
  } catch (e) {
    res.status(400).json({ message: 'Update failed' });
  }
});

router.delete('/:id', auth(['admin', 'mentor']), async (req, res) => {
  try {
    await Session.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ message: 'Delete failed' });
  }
});

export default router;
