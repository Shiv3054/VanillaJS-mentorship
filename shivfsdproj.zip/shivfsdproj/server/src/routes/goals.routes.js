import { Router } from 'express';
import Goal from '../models/Goal.js';
import { auth } from '../middleware/auth.js';

const router = Router();

router.get('/', auth(['admin', 'mentor', 'mentee']), async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { user: req.user.id };
  const items = await Goal.find(filter);
  res.json(items);
});

router.post('/', auth(['admin', 'mentor', 'mentee']), async (req, res) => {
  try {
    const { title, description, progress, status, user } = req.body;
    const owner = req.user.role === 'admin' ? (user || req.user.id) : req.user.id;
    const item = await Goal.create({ title, description, progress, status, user: owner });
    res.status(201).json(item);
  } catch (e) {
    res.status(400).json({ message: 'Create failed' });
  }
});

router.put('/:id', auth(['admin', 'mentor', 'mentee']), async (req, res) => {
  try {
    const item = await Goal.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(item);
  } catch (e) {
    res.status(400).json({ message: 'Update failed' });
  }
});

router.delete('/:id', auth(['admin', 'mentor']), async (req, res) => {
  try {
    await Goal.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ message: 'Delete failed' });
  }
});

export default router;
